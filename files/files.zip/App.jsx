import { Stage, Layer, Rect, Image as KonvaImage, Transformer, Line } from "react-konva";
import { useState, useEffect, useRef, useCallback } from "react";
import useImage from "use-image";

// ─── Canvas dimensions ────────────────────────────────────────────────────────
const CANVAS_W = 800;
const CANVAS_H = 600;
const GRID = 20;

// ─── Library: shapes extracted from Diagram Studio DSL files ─────────────────
// All images served from /assets/lib/ (copy from extract_assets.py output)
const LIBRARY = {
  "Vehículos": [
    { slug: "auto_medio",    label: "Auto mediano",      w: 40,  h: 70  },
    { slug: "auto_chico",    label: "Auto chico",        w: 36,  h: 65  },
    { slug: "car_mid",       label: "Auto mediano 2",    w: 40,  h: 70  },
    { slug: "car_compact",   label: "Auto compacto",     w: 36,  h: 65  },
    { slug: "car_veh2",      label: "Auto top-view",     w: 40,  h: 70  },
    { slug: "van",           label: "Camioneta",         w: 50,  h: 70  },
    { slug: "minivan",       label: "Minivan",           w: 50,  h: 70  },
    { slug: "pickup",        label: "Pickup",            w: 44,  h: 70  },
    { slug: "trailer",       label: "Trailer",           w: 100, h: 45  },
    { slug: "truck_veh",     label: "Camión",            w: 100, h: 45  },
    { slug: "camion_vuelco", label: "Camión vuelco",     w: 70,  h: 55  },
    { slug: "grua",          label: "Grúa",              w: 90,  h: 45  },
    { slug: "moto_arriba",   label: "Moto (arriba)",     w: 30,  h: 60  },
    { slug: "volcado",       label: "Vehículo volcado",  w: 70,  h: 50  },
    { slug: "persona",       label: "Persona",           w: 25,  h: 55  },
  ],
  "Calles y vías": [
    { slug: "road_cross_2",  label: "Cruce 2 carriles",       w: 120, h: 120 },
    { slug: "road_4lane_v",  label: "4 carriles (vert.)",     w: 60,  h: 120 },
    { slug: "road_t_top",    label: "T-inter. (arriba)",      w: 120, h: 90  },
    { slug: "road_t_bot",    label: "T-inter. (abajo)",       w: 120, h: 90  },
    { slug: "road_curve_2l", label: "Curva 2c izq.",          w: 100, h: 100 },
    { slug: "road_curve_2r", label: "Curva 2c der.",          w: 100, h: 100 },
    { slug: "road_curve_4r", label: "Curva 4c der.",          w: 100, h: 100 },
    { slug: "road_y",        label: "Y-intersección",         w: 100, h: 100 },
    { slug: "road_3junc",    label: "Bifurcación 3",          w: 100, h: 100 },
    { slug: "road_junc_l",   label: "Empalme izq.",           w: 100, h: 100 },
    { slug: "road_junc_r",   label: "Empalme der.",           w: 100, h: 100 },
    { slug: "railroad_cross",label: "Cruce ferroviario",      w: 100, h: 100 },
  ],
  "Señales": [
    { slug: "sign_stop",         label: "PARE",              w: 40, h: 40 },
    { slug: "sign_traffic_light",label: "Semáforo",          w: 30, h: 55 },
    { slug: "sign_all_way",      label: "Todos pasan",       w: 40, h: 40 },
    { slug: "sign_wrong_way",    label: "Contramano",        w: 40, h: 40 },
    { slug: "sign_left",         label: "Doblar izq.",       w: 40, h: 40 },
    { slug: "sign_right",        label: "Doblar der.",       w: 40, h: 40 },
    { slug: "sign_ped_ahead",    label: "Peatones",          w: 40, h: 40 },
    { slug: "sign_school",       label: "Escuela",           w: 40, h: 40 },
    { slug: "sign_curve",        label: "Curva",             w: 40, h: 40 },
    { slug: "sign_two_way",      label: "Doble mano",        w: 40, h: 40 },
  ],
  "Entorno": [
    { slug: "tree",        label: "Árbol",                  w: 40, h: 50 },
    { slug: "fir",         label: "Pino",                   w: 35, h: 55 },
    { slug: "house",       label: "Casa",                   w: 55, h: 50 },
    { slug: "gas_station", label: "Est. de servicio",       w: 55, h: 50 },
    { slug: "compass",     label: "Brújula Norte",          w: 50, h: 50 },
    { slug: "park",        label: "Parque",                 w: 55, h: 55 },
  ],
};

// Also include original user PNGs
const USER_ASSETS = [
  { slug: "user_auto",     label: "Auto (foto)",    src: "/assets/auto.png",        w: 50, h: 85  },
  { slug: "user_moto",     label: "Moto (foto)",    src: "/assets/moto.png",        w: 75, h: 55  },
  { slug: "user_camion",   label: "Camión (foto)",  src: "/assets/camion.png",      w: 130,h: 55  },
  { slug: "user_peaton",   label: "Peatón (foto)",  src: "/assets/peaton.png",      w: 40, h: 85  },
  { slug: "user_calle",    label: "Calle recta",    src: "/assets/calle_recta.png", w: 180,h: 75  },
  { slug: "user_rotonda",  label: "Rotonda",        src: "/assets/rotonda.png",     w: 110,h: 110 },
  { slug: "user_semaforo", label: "Semáforo (foto)",src: "/assets/semaforo.png",    w: 45, h: 90  },
  { slug: "user_stop",     label: "STOP (foto)",    src: "/assets/senial_stop.png", w: 50, h: 90  },
];

const snapVal = (v) => Math.round(v / GRID) * GRID;
let _uid = 1;
const uid = () => `el_${_uid++}`;

// ─── Single canvas element ────────────────────────────────────────────────────
function CanvasImage({ el, isSelected, onSelect, onChange, snapEnabled }) {
  const src = el.src || `/assets/lib/${el.slug}.png`;
  const [img] = useImage(src);
  const imgRef = useRef(null);
  const trRef  = useRef(null);

  useEffect(() => {
    if (isSelected && trRef.current && imgRef.current) {
      trRef.current.nodes([imgRef.current]);
      trRef.current.getLayer()?.batchDraw();
    }
  }, [isSelected]);

  return (
    <>
      <KonvaImage
        ref={imgRef} id={el.id}
        image={img}
        x={el.x} y={el.y}
        width={el.w} height={el.h}
        rotation={el.rotation || 0}
        draggable
        onClick={onSelect} onTap={onSelect}
        onDragEnd={(e) => {
          onChange({
            x: snapEnabled ? snapVal(e.target.x()) : e.target.x(),
            y: snapEnabled ? snapVal(e.target.y()) : e.target.y(),
          });
        }}
        onTransformEnd={() => {
          const n = imgRef.current;
          onChange({
            x: n.x(), y: n.y(),
            w: Math.max(8, n.width()  * n.scaleX()),
            h: Math.max(8, n.height() * n.scaleY()),
            rotation: n.rotation(),
          });
          n.scaleX(1); n.scaleY(1);
        }}
      />
      {isSelected && (
        <Transformer ref={trRef}
          borderStroke="#00d4ff" borderStrokeWidth={1.5}
          anchorStroke="#00d4ff" anchorFill="#12141c" anchorSize={8}
          keepRatio={false}
          boundBoxFunc={(o, n) => (n.width < 8 || n.height < 8 ? o : n)}
        />
      )}
    </>
  );
}

// ─── Library thumbnail button ─────────────────────────────────────────────────
function LibItem({ slug, label, src, onAdd }) {
  const imgSrc = src || `/assets/lib/${slug}.png`;
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onAdd}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      title={label}
      style={{
        display: "flex", alignItems: "center", gap: 8,
        width: "100%", padding: "5px 8px", marginBottom: 3,
        background: hov ? "#3a3a3a" : "#2a2a2a",
        border: `1px solid ${hov ? "#555" : "#383838"}`,
        borderRadius: 5, color: "#ddd", cursor: "pointer",
        fontSize: 12, textAlign: "left", transition: "all 0.1s",
      }}
    >
      <img src={imgSrc} alt={label}
        style={{ width: 28, height: 28, objectFit: "contain", flexShrink: 0, imageRendering: "pixelated" }} />
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
    </button>
  );
}

// ─── Tool button ──────────────────────────────────────────────────────────────
function ToolBtn({ icon, label, onClick, disabled, active }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        display: "flex", alignItems: "center", gap: 8,
        width: "100%", padding: "7px 10px", marginBottom: 4,
        background: active ? "#1a3040" : disabled ? "#1e1e1e" : hov ? "#383838" : "#2a2a2a",
        border: `1px solid ${active ? "#00d4ff" : disabled ? "#282828" : hov ? "#555" : "#383838"}`,
        borderRadius: 5,
        color: active ? "#00d4ff" : disabled ? "#484848" : "#ddd",
        cursor: disabled ? "not-allowed" : "pointer",
        fontSize: 12, transition: "all 0.1s",
      }}>
      <span style={{ fontSize: 14, lineHeight: 1 }}>{icon}</span>
      <span>{label}</span>
    </button>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const stageRef     = useRef(null);
  const containerRef = useRef(null);

  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const [scale, setScale]       = useState(1);
  const [stagePos, setStagePos] = useState({ x: 0, y: 10 });
  const [elements, setElements] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [gridVisible, setGridVisible]   = useState(true);
  const [snapEnabled, setSnapEnabled]   = useState(true);
  const [history, setHistory]   = useState([[]]);
  const [histIdx, setHistIdx]   = useState(0);
  const [openGroups, setOpenGroups] = useState(
    Object.fromEntries([...Object.keys(LIBRARY), "Fotos"].map(k => [k, true]))
  );

  // Resize
  useEffect(() => {
    const obs = new ResizeObserver(() => {
      if (!containerRef.current) return;
      const r = containerRef.current.getBoundingClientRect();
      if (r.width > 0 && r.height > 0)
        setContainerSize({ width: r.width, height: r.height });
    });
    if (containerRef.current) obs.observe(containerRef.current);
    return () => obs.disconnect();
  }, []);

  const getMinScale = useCallback(() => {
    if (!containerSize.width || !containerSize.height) return 1;
    return Math.min(containerSize.width / CANVAS_W, containerSize.height / CANVAS_H);
  }, [containerSize]);

  useEffect(() => {
    if (!containerSize.width || !containerSize.height) return;
    const s = getMinScale();
    setScale(s);
    setStagePos({
      x: (containerSize.width  - CANVAS_W * s) / 2,
      y: 10,
    });
  }, [containerSize]);

  // History
  const pushHist = useCallback((els) => {
    setHistory(h => [...h.slice(0, histIdx + 1), JSON.parse(JSON.stringify(els))].slice(-50));
    setHistIdx(i => Math.min(i + 1, 49));
  }, [histIdx]);

  const undo = useCallback(() => {
    if (histIdx <= 0) return;
    const i = histIdx - 1;
    setElements(JSON.parse(JSON.stringify(history[i])));
    setHistIdx(i); setSelectedId(null);
  }, [histIdx, history]);

  // Keyboard
  useEffect(() => {
    const h = (e) => {
      if (document.activeElement.tagName === "INPUT") return;
      if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); undo(); }
      if ((e.key === "Delete" || e.key === "Backspace") && selectedId) deleteSelected();
      if (e.key === "Escape") setSelectedId(null);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [selectedId, histIdx, history, undo]);

  // Add element
  const addElement = (item) => {
    const w = item.w, h = item.h;
    const el = {
      id: uid(),
      slug: item.slug,
      src: item.src,        // only for user assets
      label: item.label,
      x: snapEnabled ? snapVal(CANVAS_W / 2 - w / 2) : CANVAS_W / 2 - w / 2,
      y: snapEnabled ? snapVal(CANVAS_H / 2 - h / 2) : CANVAS_H / 2 - h / 2,
      w, h,
      rotation: 0,
    };
    const next = [...elements, el];
    setElements(next); pushHist(next); setSelectedId(el.id);
  };

  const updateEl = (id, patch) => {
    const next = elements.map(el => el.id === id ? { ...el, ...patch } : el);
    setElements(next); pushHist(next);
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    const next = elements.filter(el => el.id !== selectedId);
    setElements(next); pushHist(next); setSelectedId(null);
  };

  const moveLayer = (dir) => {
    if (!selectedId) return;
    const i = elements.findIndex(el => el.id === selectedId);
    if (i === -1) return;
    const a = [...elements];
    if (dir === "up"    && i < a.length - 1) [a[i], a[i+1]] = [a[i+1], a[i]];
    if (dir === "down"  && i > 0)             [a[i], a[i-1]] = [a[i-1], a[i]];
    if (dir === "front") { const [el] = a.splice(i, 1); a.push(el); }
    if (dir === "back")  { const [el] = a.splice(i, 1); a.unshift(el); }
    setElements(a); pushHist(a);
  };

  const saveProject = () => {
    const blob = new Blob([JSON.stringify({ elements, version: 2 }, null, 2)], { type: "application/json" });
    Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: "croquis_vial.json" }).click();
  };

  const loadProject = () => {
    const inp = Object.assign(document.createElement("input"), { type: "file", accept: ".json" });
    inp.onchange = (e) => {
      const f = e.target.files[0]; if (!f) return;
      const r = new FileReader();
      r.onload = (ev) => {
        try {
          const d = JSON.parse(ev.target.result);
          if (d.elements) { setElements(d.elements); pushHist(d.elements); setSelectedId(null); }
        } catch {}
      };
      r.readAsText(f);
    };
    inp.click();
  };

  const exportPNG = () => {
    const prev = selectedId; setSelectedId(null);
    setTimeout(() => {
      const uri = stageRef.current?.toDataURL({ pixelRatio: 2 });
      if (uri) Object.assign(document.createElement("a"), { href: uri, download: "croquis_vial.png" }).click();
      setSelectedId(prev);
    }, 60);
  };

  const clampPos = (pos, sc) => ({
    x: Math.max(containerSize.width - CANVAS_W * sc, Math.min(0, pos.x)),
    y: 10,
  });

  const handleWheel = (e) => {
    e.evt.preventDefault();
    const by = 1.05, old = scale;
    const p = stageRef.current.getPointerPosition();
    const mpt = { x: (p.x - stagePos.x) / old, y: (p.y - stagePos.y) / old };
    let ns = e.evt.deltaY > 0 ? old / by : old * by;
    ns = Math.max(getMinScale(), Math.min(4, ns));
    setScale(ns);
    setStagePos(clampPos({ x: p.x - mpt.x * ns, y: 10 }, ns));
  };

  const selectedEl = elements.find(el => el.id === selectedId);
  const libDef = selectedEl
    ? (Object.values(LIBRARY).flat().find(l => l.slug === selectedEl.slug) ||
       USER_ASSETS.find(l => l.slug === selectedEl.slug))
    : null;

  // Grid lines
  const gridLines = [];
  if (gridVisible) {
    for (let i = 0; i <= CANVAS_W / GRID; i++)
      gridLines.push(<Line key={`v${i}`} points={[i*GRID,0,i*GRID,CANVAS_H]} stroke={i%5===0?"#c8c8c8":"#e2e2e2"} strokeWidth={i%5===0?0.8:0.35} />);
    for (let i = 0; i <= CANVAS_H / GRID; i++)
      gridLines.push(<Line key={`h${i}`} points={[0,i*GRID,CANVAS_W,i*GRID]} stroke={i%5===0?"#c8c8c8":"#e2e2e2"} strokeWidth={i%5===0?0.8:0.35} />);
  }

  const toggleGroup = (g) => setOpenGroups(prev => ({ ...prev, [g]: !prev[g] }));

  const PANEL = { background: "#232323", borderRight: "1px solid #333" };
  const SECTION_HDR = {
    fontSize: 14, fontWeight: "bold", color: "#e0e0e0",
    padding: "12px 12px 8px", borderBottom: "1px solid #2e2e2e",
    display: "flex", alignItems: "center", gap: 8, flexShrink: 0,
  };
  const GROUP_HDR = (open) => ({
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "5px 8px", marginBottom: 2, cursor: "pointer",
    background: open ? "#2e2e2e" : "transparent",
    borderRadius: 4, border: "1px solid #333",
    color: "#aaa", fontSize: 11, fontWeight: "bold", letterSpacing: 1,
    textTransform: "uppercase",
  });

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%", background:"#1a1a1a", overflow:"hidden", fontFamily:"system-ui, sans-serif" }}>

      {/* Header */}
      <div style={{ textAlign:"center", padding:"8px 0", color:"#00d4ff", background:"#1c1c1c", fontSize:12, letterSpacing:3, borderBottom:"1px solid #2a2a2a", flexShrink:0, fontFamily:"'Courier New',monospace" }}>
        EDITOR DE CROQUIS DE SEGURIDAD VIAL
      </div>

      <div style={{ flex:1, display:"flex", overflow:"hidden" }}>

        {/* ── Panel izquierdo: Librería ── */}
        <div style={{ width:210, ...PANEL, display:"flex", flexDirection:"column", flexShrink:0 }}>
          <div style={SECTION_HDR}><span>📦</span> Librería</div>

          <div style={{ flex:1, overflowY:"auto", padding:"6px 6px" }}>

            {/* DSL groups */}
            {Object.entries(LIBRARY).map(([group, items]) => (
              <div key={group} style={{ marginBottom: 4 }}>
                <div style={GROUP_HDR(openGroups[group])} onClick={() => toggleGroup(group)}>
                  <span>{group}</span>
                  <span style={{ fontSize: 9 }}>{openGroups[group] ? "▲" : "▼"}</span>
                </div>
                {openGroups[group] && (
                  <div style={{ paddingTop: 3 }}>
                    {items.map(item => (
                      <LibItem key={item.slug} slug={item.slug} label={item.label}
                        onAdd={() => addElement(item)} />
                    ))}
                  </div>
                )}
              </div>
            ))}

            {/* User photo assets */}
            <div style={{ marginBottom: 4 }}>
              <div style={GROUP_HDR(openGroups["Fotos"])} onClick={() => toggleGroup("Fotos")}>
                <span>Fotos propias</span>
                <span style={{ fontSize: 9 }}>{openGroups["Fotos"] ? "▲" : "▼"}</span>
              </div>
              {openGroups["Fotos"] && (
                <div style={{ paddingTop: 3 }}>
                  {USER_ASSETS.map(item => (
                    <LibItem key={item.slug} slug={item.slug} label={item.label} src={item.src}
                      onAdd={() => addElement(item)} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Canvas ── */}
        <div ref={containerRef}
          style={{ flex:1, overflow:"hidden", background:"#1a1a1a", position:"relative" }}>
          {containerSize.width > 0 && containerSize.height > 0 && (
            <Stage ref={stageRef}
              width={containerSize.width} height={containerSize.height}
              scaleX={scale} scaleY={scale} x={stagePos.x} y={stagePos.y}
              draggable={scale > getMinScale() + 0.02}
              dragBoundFunc={(pos) => clampPos(pos, scale)}
              onDragEnd={(e) => setStagePos(clampPos({ x: e.target.x(), y: 10 }, scale))}
              onWheel={handleWheel}
              onMouseDown={(e) => { if (e.target === e.target.getStage()) setSelectedId(null); }}
            >
              <Layer>
                {/* Canvas background */}
                <Rect x={0} y={0} width={CANVAS_W} height={CANVAS_H}
                  fill="white" stroke="#999" strokeWidth={1}
                  shadowColor="rgba(0,0,0,0.45)" shadowBlur={12} shadowOffsetX={2} shadowOffsetY={2} />

                {gridLines}

                {elements.map(el => (
                  <CanvasImage key={el.id} el={el}
                    isSelected={el.id === selectedId}
                    onSelect={() => setSelectedId(el.id)}
                    onChange={(p) => updateEl(el.id, p)}
                    snapEnabled={snapEnabled}
                  />
                ))}
              </Layer>
            </Stage>
          )}

          {/* Status */}
          <div style={{ position:"absolute", bottom:8, right:12, fontSize:10, color:"#555", fontFamily:"monospace", pointerEvents:"none" }}>
            {Math.round(scale * 100)}% · {elements.length} elemento{elements.length !== 1 ? "s" : ""}
          </div>
        </div>

        {/* ── Panel derecho: Herramientas ── */}
        <div style={{ width:210, background:"#232323", borderLeft:"1px solid #333", display:"flex", flexDirection:"column", flexShrink:0 }}>
          <div style={SECTION_HDR}><span>⚙️</span> Herramientas</div>
          <div style={{ flex:1, overflowY:"auto", padding:"8px 8px" }}>

            <ToolBtn icon="💾" label="Guardar"      onClick={saveProject} />
            <ToolBtn icon="📂" label="Cargar"       onClick={loadProject} />
            <ToolBtn icon="🖼️" label="Exportar PNG" onClick={exportPNG}   />

            <div style={{ height:1, background:"#333", margin:"8px 0" }} />

            <ToolBtn icon={gridVisible ? "✅" : "⬜"} label="Grilla"      onClick={() => setGridVisible(v=>!v)} active={gridVisible} />
            <ToolBtn icon={snapEnabled ? "🧲" : "⬜"} label="Snap grilla" onClick={() => setSnapEnabled(v=>!v)} active={snapEnabled} />

            <div style={{ height:1, background:"#333", margin:"8px 0" }} />

            <ToolBtn icon="⬆️" label="Subir"     onClick={() => moveLayer("up")}    disabled={!selectedId} />
            <ToolBtn icon="⬇️" label="Bajar"     onClick={() => moveLayer("down")}  disabled={!selectedId} />
            <ToolBtn icon="⏫" label="Al frente" onClick={() => moveLayer("front")} disabled={!selectedId} />
            <ToolBtn icon="⏬" label="Al fondo"  onClick={() => moveLayer("back")}  disabled={!selectedId} />

            <div style={{ height:1, background:"#333", margin:"8px 0" }} />

            <ToolBtn icon="↩️" label="Deshacer (Ctrl+Z)" onClick={undo} disabled={histIdx <= 0} />
            <ToolBtn icon="🗑️" label="Eliminar (Del)"    onClick={deleteSelected} disabled={!selectedId} />

            {/* Properties panel */}
            {selectedEl && (
              <div style={{ marginTop:10, padding:"10px", background:"#1e1e1e", borderRadius:6, border:"1px solid #333" }}>
                <div style={{ fontSize:10, color:"#666", marginBottom:4 }}>Seleccionado</div>
                <div style={{ fontSize:12, color:"#e0e0e0", fontWeight:"bold", marginBottom:10 }}>
                  {selectedEl.label}
                </div>

                {/* Rotation */}
                <div style={{ fontSize:10, color:"#777", marginBottom:3 }}>
                  Rotación: {Math.round(selectedEl.rotation || 0)}°
                </div>
                <input type="range" min={0} max={360}
                  value={Math.round(selectedEl.rotation || 0)}
                  onChange={e => updateEl(selectedId, { rotation: parseFloat(e.target.value) })}
                  style={{ width:"100%", accentColor:"#00d4ff", marginBottom:10 }}
                />

                {/* Quick scale */}
                <div style={{ fontSize:10, color:"#777", marginBottom:4 }}>Escala rápida</div>
                <div style={{ display:"flex", gap:3, marginBottom:8 }}>
                  {[0.5, 1, 1.5, 2].map(f => {
                    const def = libDef;
                    return (
                      <button key={f}
                        onClick={() => def && updateEl(selectedId, { w: def.w * f, h: def.h * f })}
                        style={{ flex:1, padding:"3px 0", background:"#2a2a2a", border:"1px solid #3a3a3a", borderRadius:4, color:"#bbb", cursor:"pointer", fontSize:10 }}>
                        ×{f}
                      </button>
                    );
                  })}
                </div>

                {/* Size inputs */}
                <div style={{ display:"flex", gap:4 }}>
                  {[["W", "w"], ["H", "h"]].map(([lbl, key]) => (
                    <div key={key} style={{ flex:1 }}>
                      <div style={{ fontSize:9, color:"#666", marginBottom:2 }}>{lbl}</div>
                      <input type="number" min={8} max={800}
                        value={Math.round(selectedEl[key])}
                        onChange={e => updateEl(selectedId, { [key]: parseFloat(e.target.value) || 8 })}
                        style={{ width:"100%", background:"#2a2a2a", border:"1px solid #3a3a3a", borderRadius:3, color:"#e0e0e0", padding:"3px 5px", fontSize:10, boxSizing:"border-box" }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Layers list */}
            {elements.length > 0 && (
              <div style={{ marginTop:10 }}>
                <div style={{ fontSize:10, color:"#555", marginBottom:5, letterSpacing:1, textTransform:"uppercase" }}>
                  Capas ({elements.length})
                </div>
                <div style={{ maxHeight:160, overflowY:"auto" }}>
                  {[...elements].reverse().map((el, i) => (
                    <div key={el.id} onClick={() => setSelectedId(el.id)}
                      style={{
                        display:"flex", alignItems:"center", gap:6,
                        padding:"3px 6px", marginBottom:2, borderRadius:4,
                        cursor:"pointer",
                        background: el.id===selectedId ? "#1a3040" : "transparent",
                        border: `1px solid ${el.id===selectedId ? "#00d4ff44" : "transparent"}`,
                      }}>
                      <img src={el.src || `/assets/lib/${el.slug}.png`} alt=""
                        style={{ width:16, height:16, objectFit:"contain", flexShrink:0 }} />
                      <span style={{ fontSize:10, color: el.id===selectedId ? "#e0e0e0" : "#888", flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                        {el.label}
                      </span>
                      <span style={{ fontSize:9, color:"#444" }}>{elements.length - i}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
